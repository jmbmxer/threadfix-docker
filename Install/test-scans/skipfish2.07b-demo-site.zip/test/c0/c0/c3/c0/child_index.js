var child = [
  { 'dupe': false, 'type': 64, 'name': 'command=1', 'dir': 'c0', 'linked': 5, 'url': 'http://10.2.100.1/demo/EvalInjection.php/EvalInjection2.php DATA:command=1', 'fetched': true, 'code': 200, 'len': 526, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 1, 0, 0, 0, 0 ], 'sig': 0xffbed5cd }
];
