var issue = [
  { 'severity': 2, 'type': 30601, 'extra': '', 'fetched': true, 'code': 200, 'len': 526, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 0, 'type': 10803, 'extra': '', 'fetched': true, 'code': 200, 'len': 526, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i1' },
  { 'severity': 0, 'type': 10204, 'extra': 'X-Powered-By', 'fetched': true, 'code': 200, 'len': 526, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i2' }
];
