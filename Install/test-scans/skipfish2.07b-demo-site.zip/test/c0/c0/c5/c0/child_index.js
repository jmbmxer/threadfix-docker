var child = [
  { 'dupe': false, 'type': 64, 'name': 'action=PathTraversal.php', 'dir': 'c0', 'linked': 2, 'url': 'http://10.2.100.1/demo/index.php/PathTraversal.php?action=PathTraversal.php', 'fetched': true, 'code': 200, 'len': 704, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 1, 0, 0, 0, 0 ], 'sig': 0xffbed5cd }
];
