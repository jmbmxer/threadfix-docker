var issue = [
  { 'severity': 3, 'type': 40402, 'extra': 'PHP error (text)', 'fetched': true, 'code': 200, 'len': 461, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 0, 'type': 10803, 'extra': '', 'fetched': true, 'code': 200, 'len': 461, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i1' }
];
