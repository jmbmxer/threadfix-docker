var issue = [
  { 'severity': 3, 'type': 40501, 'extra': 'responses for ./val and .../val look different', 'fetched': true, 'code': 200, 'len': 948, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 3, 'type': 40501, 'extra': 'responses for .\x5cval and ...\x5cval look different', 'fetched': true, 'code': 200, 'len': 948, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i1' },
  { 'severity': 3, 'type': 40402, 'extra': 'PHP error (text)', 'fetched': true, 'code': 200, 'len': 461, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i2' },
  { 'severity': 3, 'type': 40401, 'extra': 'PHP source', 'fetched': true, 'code': 200, 'len': 948, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i3' },
  { 'severity': 3, 'type': 40304, 'extra': '', 'fetched': true, 'code': 200, 'len': 825, 'decl_mime': 'text/html', 'sniff_mime': 'text/plain', 'cset': '[none]', 'dir': 'i4' },
  { 'severity': 3, 'type': 40301, 'extra': 'text/xml', 'fetched': true, 'code': 200, 'len': 793, 'decl_mime': 'text/html', 'sniff_mime': 'text/xml', 'cset': '[none]', 'dir': 'i5' },
  { 'severity': 3, 'type': 40301, 'extra': 'text/plain', 'fetched': true, 'code': 200, 'len': 825, 'decl_mime': 'text/html', 'sniff_mime': 'text/plain', 'cset': '[none]', 'dir': 'i6' },
  { 'severity': 3, 'type': 40101, 'extra': 'injected \x27\x3csfi...\x3e\x27 tag seen in HTML', 'fetched': true, 'code': 200, 'len': 825, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i7' },
  { 'severity': 0, 'type': 10803, 'extra': '', 'fetched': true, 'code': 200, 'len': 331, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i8' },
  { 'severity': 0, 'type': 10801, 'extra': 'text/plain', 'fetched': true, 'code': 200, 'len': 794, 'decl_mime': 'text/html', 'sniff_mime': 'text/plain', 'cset': '[none]', 'dir': 'i9' }
];
