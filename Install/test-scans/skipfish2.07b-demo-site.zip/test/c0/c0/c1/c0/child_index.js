var child = [
  { 'dupe': false, 'type': 128, 'name': 'nul', 'dir': 'c0', 'linked': 0, 'url': 'http://10.2.100.1/demo/PathTraversal.php?action=nul', 'fetched': true, 'code': 200, 'len': 255, 'decl_mime': 'text/html', 'sniff_mime': 'text/plain', 'cset': '[none]', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 2, 0, 0, 1, 0 ], 'sig': 0xf73e8e09 },
];
