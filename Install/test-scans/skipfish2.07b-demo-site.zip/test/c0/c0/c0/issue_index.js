var issue = [
  { 'severity': 0, 'type': 10404, 'extra': 'Directory listing', 'fetched': true, 'code': 200, 'len': 297, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'UTF-8', 'dir': 'i0' },
  { 'severity': 0, 'type': 10403, 'extra': '', 'fetched': true, 'code': 501, 'len': 239, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'iso-8859-1', 'dir': 'i1' },
  { 'severity': 0, 'type': 10204, 'extra': 'X-Pad', 'fetched': true, 'code': 200, 'len': 297, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'UTF-8', 'dir': 'i2' }
];
