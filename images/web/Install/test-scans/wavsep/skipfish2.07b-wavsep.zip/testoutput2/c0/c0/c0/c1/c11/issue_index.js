var issue = [
  { 'severity': 2, 'type': 30601, 'extra': '', 'fetched': true, 'code': 200, 'len': 578, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'ISO-8859-1', 'dir': 'i0' },
  { 'severity': 0, 'type': 10901, 'extra': '', 'fetched': true, 'code': 200, 'len': 578, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'ISO-8859-1', 'dir': 'i1' }
];
