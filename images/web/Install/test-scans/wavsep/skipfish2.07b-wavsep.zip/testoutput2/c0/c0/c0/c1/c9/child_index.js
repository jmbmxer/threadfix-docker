var child = [
  { 'dupe': false, 'type': 64, 'name': 'userinput=textvalue', 'dir': 'c0', 'linked': 5, 'url': 'https://satoffice043:8443/wavsep/active/RXSS-Detection-Evaluation-GET/Case10-Js2DoubleQuoteJsEventScope.jsp?userinput=textvalue', 'fetched': true, 'code': 200, 'len': 493, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'ISO-8859-1', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 1, 0 ], 'sig': 0xb41377fd }
];
