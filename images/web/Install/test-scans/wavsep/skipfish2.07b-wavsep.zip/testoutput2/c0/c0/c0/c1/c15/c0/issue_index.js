var issue = [
  { 'severity': 3, 'type': 40102, 'extra': 'frame', 'fetched': true, 'code': 200, 'len': 481, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'ISO-8859-1', 'dir': 'i0' },
  { 'severity': 2, 'type': 30402, 'extra': 'frame', 'fetched': true, 'code': 200, 'len': 481, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'ISO-8859-1', 'dir': 'i1' }
];
