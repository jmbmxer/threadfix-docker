var issue = [
  { 'severity': 3, 'type': 40102, 'extra': 'img', 'fetched': true, 'code': 200, 'len': 411, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'ISO-8859-1', 'dir': 'i0' },
  { 'severity': 3, 'type': 40101, 'extra': 'injected \x27sfi..\x27 parameter value in a tag', 'fetched': true, 'code': 200, 'len': 449, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'ISO-8859-1', 'dir': 'i1' },
  { 'severity': 2, 'type': 30402, 'extra': 'img', 'fetched': true, 'code': 200, 'len': 416, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'ISO-8859-1', 'dir': 'i2' }
];
