var child = [
  { 'dupe': true, 'type': 64, 'name': 'userinput=1234', 'dir': 'c0', 'linked': 5, 'url': 'https://satoffice043:8443/wavsep/active/RXSS-Detection-Evaluation-GET/Case28-Js2ScriptTagMLCommentScope.jsp?userinput=1234', 'fetched': true, 'code': 200, 'len': 435, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'ISO-8859-1', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0xffbfffff }
];
