var issue = [
  { 'severity': 3, 'type': 40101, 'extra': 'injected syntax in JS/CSS code', 'fetched': true, 'code': 200, 'len': 498, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'ISO-8859-1', 'dir': 'i0' }
];
