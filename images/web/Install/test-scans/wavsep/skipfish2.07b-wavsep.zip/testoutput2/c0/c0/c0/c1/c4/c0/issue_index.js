var issue = [
  { 'severity': 3, 'type': 40102, 'extra': 'frame', 'fetched': true, 'code': 200, 'len': 465, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'ISO-8859-1', 'dir': 'i0' },
  { 'severity': 3, 'type': 40101, 'extra': 'injected \x27\x3csfi...\x3e\x27 tag seen in HTML', 'fetched': true, 'code': 200, 'len': 485, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'ISO-8859-1', 'dir': 'i1' },
  { 'severity': 2, 'type': 30402, 'extra': 'frame', 'fetched': true, 'code': 200, 'len': 470, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'ISO-8859-1', 'dir': 'i2' }
];
