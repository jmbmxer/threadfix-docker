var issue = [
  { 'severity': 0, 'type': 10403, 'extra': '', 'fetched': true, 'code': 501, 'len': 1187, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'utf-8', 'dir': 'i0' },
  { 'severity': 0, 'type': 10201, 'extra': 'userinput', 'fetched': true, 'code': 200, 'len': 18, 'decl_mime': '[none]', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i1' }
];
